<?php $title = 'Category Page'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include 'layouts/top_header.php'; ?>
<body>

    <?php include 'layouts/header.php'; ?>
    <section class="body" id="main_body">
        <div class="container-fluid mt-3">
            <div class="row mb-3">
                <div class="col-12">
                    <span id="add" class="text-center"></span>
                </div>
            </div>
            <div class="row mx-0">

                
                <div class="col-12 col-md-12 col-xl-8 col-sm-8">
                    <div class="d-flex justify-content-center">
                        <h2 class="text-center position-relative botom_line"><span class="text-blue"><strong>Tag:</strong></span><span class="text-uppercase">Laravel</span>
                        </h2>
                    </div>
                    <div class="site-description mb-5">
                        <h4 class="text-center">
                            <a class="text-blue" href="index.php">ItSolutionStuff.com</a> have tutorials for Laravel tag, here you can study articles of Laravel tag, Laravel tag posts collection, most popular and useful tutorials of Laravel tag, here you can find list of all relevant posts and example about Laravel tag, we have lists of tutorials and examples about Laravel tag. very simple and quick example collection of Latest Laravel tag.

                        </h4>
                    </div>
                    <div class="mb-5 google_search_ad"></div>
                    <section class="tag_post container mb-50">
                        <div class="row">
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-6 col-sm-12">
                                <div class="card_container">
                                    <div class="card" data-label="May 24, 2022">
                                        <div class="card-container">
                                            <h4><a href="#">Laravel pagination pretty url example</a></h4>
                                             
                                            <div class="d-flex">
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-tag"></i></span>
                                                    <a href="#" class="font-bolder mb-0">Laravel</a>
                                                  
                                                </div>
                                                <div class="col-3">
                                                    <span class="text-sm"><i class="fa-solid fa-briefcase"></i></span>
                                                    <a href="#" class="font-bolder mb-0">laravel</a>
                                                  
                                                </div>
                                                <div class="col-6">
                                                    <span class="text-sm"><i class="fa-solid fa-user"></i></span>
                                                    <a href="#" class="font-bolder mb-0">By Hardk savani</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row action-btns-bottom">
                            <div class="col justify-content-center d-flex">
                                <a href="#">
                                    <button type="button" class="btn btn-primary btn-lg disabled previous">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path  fill="currentColor" d="M192 448c-8.188 0-16.38-3.125-22.62-9.375l-160-160c-12.5-12.5-12.5-32.75 0-45.25l160-160c12.5-12.5 32.75-12.5 45.25 0s12.5 32.75 0 45.25L77.25 256l137.4 137.4c12.5 12.5 12.5 32.75 0 45.25C208.4 444.9 200.2 448 192 448z"/></svg>
                                         Previous
                                     </button>
                                </a>
                                <a href="#page=2">
                                    <button type="button" class="btn btn-secondary btn-lg next ms-3" style="background-color:#1E5792">Next
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512"><!--! Font Awesome Pro 6.1.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M64 448c-8.188 0-16.38-3.125-22.62-9.375c-12.5-12.5-12.5-32.75 0-45.25L178.8 256L41.38 118.6c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0l160 160c12.5 12.5 12.5 32.75 0 45.25l-160 160C80.38 444.9 72.19 448 64 448z"/></svg>
                                    </button>
                                </a>
                            </div>
                        </div>
                        

                    </section>
                    <section class="featured-post container mb-50">
                        <div class="d-flex justify-content-center">
                            <h2 class="text-center position-relative botom_line"><strong>Featured</strong>  Post
                            </h2>
                        </div>
                        <div class="row mt-4">
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-line-chart.png">
                                    </div>
                                    <a href="#">Angular Line Chart Example Tutorial</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-11-bar-chart.png">
                                    </div>
                                    <a href="#">Angular 11 Bar Chart using ng2-charts Example</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-bar-chart.png">
                                    </div>
                                    <a href="#">Angular Bar Chart Example Tutorial</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-11-doughnut-chart.png">
                                    </div>
                                    <a href="#">Angular 11 Doughnut Chart using ng2-charts Example</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-doughnut-chart.png">
                                    </div>
                                    <a href="#">Angular Doughnut Chart Example Tutorial</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-xl-4 col-sm-6">
                                <div class="feature-post-box shadow bg-body rounded">
                                    <div class="post-image">
                                        <img src="images/angular-11-radar-chart.png">
                                    </div>
                                    <a href="#">Angular 11 Radar Chart using ng2-charts Example</a>
                                    <label class="bottom-line"></label>
                                </div>
                            </div>
                        </div>
                    </section>
                    
                </div>
                <?php include 'layouts/sidebar.php'; ?>
            </div>
        </div>
    </section>

    <?php include 'layouts/footer.php'; ?>
    
</body>
</html>